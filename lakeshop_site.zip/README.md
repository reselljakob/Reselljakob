
# 🛍️ Reselljakob – Premium Digital Vendor Store

**Reselljakob** är en stilren, minimalistisk webbutik för försäljning av digitala **vendor packs** och **resell bundles**.  
Webbsidan är designad för att efterlikna en specifik layout inspirerad av moderna återförsäljningssidor – med fokus på **ren struktur, tydlig prissättning och visuell konsekvens**.

## 🎨 Design & Layout
Sidan använder en **helsvart bakgrund** med kontrasterande **blå produktkort** för varje vara. Varje kort innehåller:

- En produktbild
- Produktens namn (t.ex. “Cologne Vendor”)
- Ett tydligt pris i USD (t.ex. $4.99)
- En jämn och centrerad layout i två kolumner

Högst upp visas en stor titel: **“Products”**, följt av butikens namn i grå text:  
**Reselljakob — reselljakob.store**

## 📦 Produkter
Sidan presenterar sex digitala produkter:

1. **Cologne Vendor** – $4.99  
2. **Labuubu Vendor** – $4.99  
3. **Clothes Vendor** – $4.99  
4. **All Electronics Vendor** – $4.99  
5. **All Vendors Bundle** – $9.99  
6. **All Vendors + Resell Rights** – $9.99  

Alla produkter är tänkta som **digitala nedladdningar** eller direktleveranser efter betalning.

## ⚙️ Teknik & Funktionalitet
- Fullt byggd med **ren HTML och CSS** – inga beroenden
- **Responsiv design**: fungerar på både mobil och dator
- **Extremt snabb laddningstid** tack vare lättviktiga element
- Publiceras gratis via **GitHub Pages**

## 🎯 Mål
Webbsidan är framtagen för att:
- Förenkla försäljning av digitala varor
- Se modern och trovärdig ut
- Efterlikna en framgångsrik butiksmall med AI-genererad struktur

## 🌐 Live-version
Kommer att publiceras på:  
`https://yourusername.github.io/reselljakob`
